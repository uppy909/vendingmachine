package com.hca.bean;

public class BeanCls {

	private String drinkname;
	private int amount;
	public String getDrinkname() {
		return drinkname;
	}
	public void setDrinkname(String drinkname) {
		this.drinkname = drinkname;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	
	
}
