package com.hca.Dao;

import java.util.List;

import com.hca.bean.BeanCls;
import com.hca.bean.Items;

public interface Dao {

	public int insert(BeanCls bean);

	public List<BeanCls> getReports();

	public List<Items> getItems();

}
