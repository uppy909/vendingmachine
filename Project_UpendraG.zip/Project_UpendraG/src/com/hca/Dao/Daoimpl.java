package com.hca.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.hca.bean.BeanCls;
import com.hca.bean.Items;
import com.hca.singleton.ConnCls;

public class Daoimpl implements Dao {

	private Connection con;

	public Daoimpl() {
		ConnCls connCs = ConnCls.CCls.c;
		con = connCs.getConnection();
	}

	@Override
	public int insert(BeanCls bean) {
		int statuc = 0;
		String sql = "insert into sodatable(drinkname,amount) values(?,?)";
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, bean.getDrinkname());
			ps.setInt(2, bean.getAmount());
			statuc = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return statuc;
	}

	@Override
	public List<BeanCls> getReports() {
		List<BeanCls> list = new ArrayList<BeanCls>();
		String sql = "select * from sodatable";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				BeanCls bean = new BeanCls();
				bean.setDrinkname(rs.getString(1));
				bean.setAmount(rs.getInt(2));
				list.add(bean);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}

	@Override
	public List<Items> getItems() {
		List<Items> list = new ArrayList<Items>();
		String sql = "select * from items";
		try {
			Items item = new Items();
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				item.setProductname(rs.getString(1));
				item.setPrice(rs.getInt(2));
				list.add(item);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

}
