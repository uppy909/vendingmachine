package com.hca.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hca.Dao.Dao;
import com.hca.Dao.Daoimpl;
import com.hca.bean.BeanCls;
import com.hca.bean.Items;

/**
 * Servlet implementation class Controller
 */
@WebServlet("/Controller")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Dao dao = new Daoimpl();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Controller() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			doGet(request,response);
			
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		String a = request.getParameter("a");
		List<Items> items=new ArrayList<Items>();
		request.setAttribute("menulist", dao.getItems());
		
		BeanCls bean = new BeanCls();
		RequestDispatcher rd = null;
		if (a.equalsIgnoreCase("book")) {
			rd = request.getRequestDispatcher("/create.jsp");
			rd.forward(request, response);
		} else if (a.equalsIgnoreCase("report")) {
			rd = request.getRequestDispatcher("/reports.jsp");
			request.setAttribute("drinklist", dao.getReports());
			rd.include(request, response);
		} else if (a.equalsIgnoreCase("buy")) {
			String drinkname = request.getParameter("t1");
			int amount = Integer.parseInt(request.getParameter("t2"));
			if(amount ==10 && amount >10) {
				int r=amount-10;
				bean.setDrinkname(drinkname);
				bean.setAmount(amount);
				int status=dao.insert(bean);
				if(status >0) {
					out.print("Please collect the drink...");
					out.print("Please collect the remaing balance..."+r);
					request.getRequestDispatcher("/create.jsp").include(request, response);
				}else {
					out.print("...");
					request.getRequestDispatcher("/create.jsp").forward(request, response);
				}
			}else if(amount < 10){
				int rr=amount-10;
				out.print("Sorry..Please provide the remaing balance to buy the drink...."+rr);
				request.getRequestDispatcher("/create.jsp").include(request, response);
			}

		}

	}

}
