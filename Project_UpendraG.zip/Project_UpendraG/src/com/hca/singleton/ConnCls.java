package com.hca.singleton;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;



public class ConnCls {

	private ConnCls() {
	}
	public static class CCls{
		public static ConnCls c=new ConnCls();
	}
	public static Connection con= null;
	public Connection getConnection() {
		InputStream inputStream=ConnCls.class.getClassLoader().getResourceAsStream("/com/hca/Poperties/db.properties");
		Properties properties= new Properties();
		try {
		properties.load(inputStream);
			String driver=properties.getProperty("driver");
			String url=properties.getProperty("url");
			String user=properties.getProperty("user");
			String pass=properties.getProperty("pass");
			
			Class.forName(driver);
			con=DriverManager.getConnection(url,user,pass);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
}
